import os
import json
import requests
import streamlit as st

from langchain_groq import ChatGroq
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import JsonOutputParser,StrOutputParser
from langchain_core.exceptions import OutputParserException

# Set your Groq API key
os.environ["GROQ_API_KEY"] = ""

llm = ChatGroq(model_name="llama3-8b-8192", temperature=0.1)
parser = JsonOutputParser()
parser2=StrOutputParser()

llm2 = ChatGroq(model_name="llama3-8b-8192", temperature=0.2)

def file_complaint_api(name, phone, email, details):
    json_data = {
        "name": name,
        "phone_number": phone,
        "email": email,
        "complaint_details": details
    }
    response = requests.post('http://127.0.0.1:8000/complaints', json=json_data)
    return response

def get_complaint_api(complaint_id):
    response = requests.get(f'http://127.0.0.1:8000/complaints/{complaint_id}')
    return response

def safe_parse_json(output):
    try:
        return parser.parse(output)
    except OutputParserException:
        fixed = output.replace("'", '"')
        try:
            return json.loads(fixed)
        except Exception:
            raise

prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a highly accurate text classification system for customer complaints. "
               "Your task is to analyze user input and classify it into one of two categories: "
               "'FILE' (for filing a new complaint) or 'RETRIEVE' (for checking the status of an existing complaint or retrieving its details) "
               "or 'NONE' (if you are not sure about the user intent then guide the user politely and accordingly ). "
               "For each classification, you must also provide an appropriate, helpful message to the user based on past history conversation that guides them on the next step. "
               "The output must always be a valid JSON object with 'category' and 'message' keys. "
               "IMPORTANT: Always use double quotes (\") for all keys and string values in your JSON output. "
               "Never use single quotes. Only output the JSON object, nothing else."),
    ("user", "I want to file a new complaint about a faulty product."),
    ("assistant", '{{"category": "FILE", "message": "Please provide your full name, phone number, email address, and a detailed description of your complaint."}}'),
    ("user", "What's the status of my complaint ID 12345?"),
    ("assistant", '{{"category": "RETRIEVE", "message": "Please provide your complaint ID to check its status."}}'),
    ("user", "I need to submit a complaint regarding late delivery."),
    ("assistant", '{{"category": "FILE", "message": "Please provide your full name, phone number, email address, and a detailed description of your complaint, including order number and expected delivery date."}}'),
    ("user", "Can I get information on my previous complaint?"),
    ("assistant", '{{"category": "RETRIEVE", "message": "Please provide your complaint ID to retrieve information about it."}}'),
    ("user", "My flight was cancelled, I want to complain."),
    ("assistant", '{{"category": "FILE", "message": "Please provide your full name, phone number, email address, and a detailed description of your complaint, including flight number and date."}}'),
    ("user", "I forgot my complaint ID, but I need to see its status."),
    ("assistant", '{{"category": "RETRIEVE", "message": "Please provide your complaint ID to check its status."}}'),
    ("user", "Hello"),
    ("assistant", '{{"category": "NONE", "message": "Hello! i am your complaint registering assistant please tell me about your complaint and i am happy to process it further."}}'),
    ("user", "{user_input}")
])

prompt2=ChatPromptTemplate.from_messages([
    ('system','You are helpfull AI assistant ,you will be provided a JSON by user which contains detail about the user complaint, your task is to explain user about this complaint under 50 words'),
    ('user',"{user_input}")
])

classification_chain = prompt | llm | parser

complaint_exp_chain=prompt2 | llm2 | parser2

st.set_page_config(page_title="Complaint Chatbot", page_icon="🤖")
st.title("Complaint Chatbot 🤖")

# State initialization
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []
if "none_trigger" not in st.session_state:
    st.session_state.none_trigger = 0
if "disabled" not in st.session_state:
    st.session_state.disabled = False
if "awaiting_file_form" not in st.session_state:
    st.session_state.awaiting_file_form = False
if "awaiting_retrieve_form" not in st.session_state:
    st.session_state.awaiting_retrieve_form = False
if "pending_file_message" not in st.session_state:
    st.session_state.pending_file_message = ""
if "pending_retrieve_message" not in st.session_state:
    st.session_state.pending_retrieve_message = ""

def handle_user_input(user_input):
    result = classification_chain.invoke({"user_input": user_input})
    st.session_state.chat_history.append(("user", user_input))
    st.session_state.chat_history.append(("ai", result['message']))
    if result['category'] == 'NONE':
        st.session_state.none_trigger += 1
        if st.session_state.none_trigger > 3:
            st.session_state.chat_history.append(("ai", "Sorry! I will not be able to handle your requests further as it seems your requests are not related to my context."))
            st.session_state.disabled = True
    elif result['category'] == 'FILE':
        st.session_state.awaiting_file_form = True
        st.session_state.pending_file_message = result['message']
    elif result['category'] == 'RETRIEVE':
        st.session_state.awaiting_retrieve_form = True
        st.session_state.pending_retrieve_message = result['message']

st.markdown("---")
for sender, message in st.session_state.chat_history:
    if sender == "user":
        st.markdown(f"**You:** {message}")
    else:
        st.markdown(f"<span style='color: blue; font-weight: bold;'>🤖 AI: {message}</span>", unsafe_allow_html=True)

        # st.markdown(f"**🤖 AI:** {message}")

# Show FILE form if needed
if st.session_state.awaiting_file_form:
    st.info(st.session_state.pending_file_message)
    with st.form("file_complaint_form", clear_on_submit=True):
        name = st.text_input("Full Name")
        phone = st.text_input("Phone Number")
        email = st.text_input("Email Address")
        details = st.text_area("Complaint Details")
        submitted = st.form_submit_button("Submit Complaint")
        if submitted:
            response = file_complaint_api(name, phone, email, details)
            try:
                data = response.json()
                st.session_state.chat_history.append(("ai", f"Thanks for the details, Your complaint id is {data['complaint_id']}, please save it for retrieval purposes."))
            except Exception:
                st.session_state.chat_history.append(("ai", "There was an error submitting your complaint. Please try again."))
            st.session_state.awaiting_file_form = False
            st.session_state.pending_file_message = ""
            st.rerun()

# Show RETRIEVE form if needed
elif st.session_state.awaiting_retrieve_form:
    st.info(st.session_state.pending_retrieve_message)
    with st.form("retrieve_complaint_form", clear_on_submit=True):
        complaint_id = st.text_input("Complaint ID")
        submitted = st.form_submit_button("Retrieve Complaint")
        if submitted:
            response = get_complaint_api(complaint_id)
            try:
                data = response.json()
                exp=complaint_exp_chain.invoke({"user_input":data})
                st.session_state.chat_history.append(("ai", f"{exp}"))
            except Exception:
                st.session_state.chat_history.append(("ai", "There was an error retrieving your complaint. Please check your complaint ID."))
            st.session_state.awaiting_retrieve_form = False
            st.session_state.pending_retrieve_message = ""
            st.rerun()

# Show input only if not waiting for a form
elif not st.session_state.disabled:
    user_input = st.text_input("Type your message:", key="user_input")
    if st.button("Send"):
        if user_input.strip():
            handle_user_input(user_input)
            st.rerun()
else:
    st.warning("Chatbot is disabled due to repeated unrelated requests.")
