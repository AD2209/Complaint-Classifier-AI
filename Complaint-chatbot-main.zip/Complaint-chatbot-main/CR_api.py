import uvicorn
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Dict
from uuid import UUID, uuid4
from datetime import datetime
import sqlite3


# 1. Initialize FastAPI app
app = FastAPI(
    title="Complaint Management API",
    description="A simple API for managing customer complaints."
)
# 2. Define Pydantic models

# Model for creating a new complaint (request body for POST /complaints)
class ComplaintCreate(BaseModel):
    name: str = Field(..., description="Name of the person making the complaint.")
    phone_number: str = Field(..., description="Contact phone number.")
    email: str = Field(..., description="Contact email address.")
    complaint_details: str = Field(..., description="Detailed description of the complaint.")

# Model for storing complaint data internally (includes ID and timestamp)
class ComplaintInDB(ComplaintCreate):
    complaint_id: UUID = Field(default_factory=uuid4, description="Unique identifier for the complaint.")
    complaint_status: str = Field(default="Pending", description="Current status of the complaint.")
    created_at: datetime = Field(default_factory=datetime.utcnow, description="Timestamp when the complaint was created (UTC).")

# Model for retrieving complaint details (response for GET /complaints/{complaint_id})
class ComplaintResponse(BaseModel):
    complaint_id: UUID = Field(..., description="Unique identifier for the complaint.")
    name: str = Field(..., description="Name of the person making the complaint.")
    phone_number: str = Field(..., description="Contact phone number.")
    email: str = Field(..., description="Contact email address.")
    complaint_details: str = Field(..., description="Detailed description of the complaint.")
    # Renaming "created_at" to "Created At" for the output as per request
    created_At: datetime = Field(alias="created_at", description="Timestamp when the complaint was created.")
    complaint_status: str = Field(default="Pending", description="Current status of the complaint.")
    

    class Config:
        # This allows the field 'Created At' to be initialized from 'created_at' when creating a ComplaintResponse from ComplaintInDB
        populate_by_name = True
        # For compatibility with UUID and datetime objects in JSON serialization
        json_encoders = {
            datetime: lambda dt: dt.isoformat() + "Z", # Format datetime to ISO 8601 with 'Z' for UTC
            UUID: lambda uuid: str(uuid)
        }

# 3. In-memory database (for demonstration purposes)
# In a real application, this would be a persistent database.
db: Dict[UUID, ComplaintInDB] = {}

# 4. Endpoints

@app.post(
    "/complaints",
    response_model=Dict[str, str], # Output format is a simple dictionary for message
    summary="Create a new complaint",
    description="Allows a user to submit a new complaint with their contact details and complaint description."
)
async def create_complaint(complaint: ComplaintCreate):
    """
    Creates a new complaint entry.

    Args:
        complaint (ComplaintCreate): The complaint details provided by the user.

    Returns:
        Dict[str, str]: A dictionary containing the generated complaint ID and a success message.
    """
    new_complaint = ComplaintInDB(**complaint.dict())
    # Loading DB
    conn = sqlite3.connect("complaints.db")
    # Inserting into SQLite DB
    cursor = conn.cursor()
    # db[new_complaint.complaint_id] = new_complaint
    cursor.execute("""
        INSERT INTO complaints (
            complaint_id, name, phone_number, email, complaint_details, created_at,complaint_status
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (str(new_complaint.complaint_id),new_complaint.name,new_complaint.phone_number,new_complaint.email,new_complaint.complaint_details,new_complaint.created_at,new_complaint.complaint_status))
    conn.commit()
    conn.close()

    return {
        "complaint_id": str(new_complaint.complaint_id),
        "complaint_status":new_complaint.complaint_status,
        "message": "Complaint created successfully"
    }

@app.get(
    "/complaints/{complaint_id}",
    response_model=ComplaintResponse,
    summary="Retrieve complaint details by ID",
    description="Fetches the complete details of a complaint using its unique ID."
)
async def get_complaint(complaint_id: UUID):
    """
    Retrieves the details of a specific complaint by its ID.

    Args:
        complaint_id (UUID): The unique ID of the complaint to retrieve.

    Returns:
        ComplaintResponse: The details of the found complaint.

    Raises:
        HTTPException: If no complaint is found with the given ID (404 Not Found).
    """
    conn = sqlite3.connect("complaints.db")
    cursor = conn.cursor()
    # complaint = db.get(complaint_id)
    cursor.execute("SELECT * FROM complaints WHERE complaint_id='{0}'".format(str(complaint_id)))
    complaint = cursor.fetchone()
    conn.close()
    if complaint==None:
        raise HTTPException(status_code=404, detail="Complaint not found")
    # Convert ComplaintInDB to ComplaintResponse, handling the alias
    return ComplaintResponse(
        complaint_id=complaint[0],
        name=complaint[1],
        phone_number=complaint[2],
        email=complaint[3],
        complaint_details=complaint[4],
        **{"created_at": complaint[5]}, # Pass created_at for the alias
        complaint_status=complaint[6]
    )

# You can run this application using Uvicorn from your terminal:
# uvicorn main:app --reload
# (Assuming you save this code as main.py)

# Or, if you want to run it directly from a script (for testing/development)
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
