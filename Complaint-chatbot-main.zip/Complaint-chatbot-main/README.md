# Complaint Chatbot

A simple end-to-end complaint management system with a conversational AI frontend and a FastAPI backend. Users can file new complaints or retrieve the status/details of existing complaints via a chat interface.

## Features

- **Conversational Chatbot UI**: Built with Streamlit and LangChain, powered by Llama3 via Groq API.
- **Complaint Filing**: Users can file complaints by providing their details and complaint description.
- **Complaint Retrieval**: Users can check the status or details of their complaints using a unique complaint ID.
- **FastAPI Backend**: Handles complaint creation and retrieval, storing data in a SQLite database.
- **Intent Classification**: AI classifies user intent as filing, retrieving, or unrelated, and guides the conversation accordingly.

## Project Structure
```
complaint_chatbot/
├── CR_api.py           # FastAPI backend for complaint management
├── frontend_chat.py    # Streamlit frontend chatbot UI
├── complaints.db       # SQLite database (auto-created)
├── README.md           # Project documentation
└── __pycache__/        # Python cache files
```

## Getting Started

### 1. Backend Setup (FastAPI)

1. **Install dependencies**:
    ```sh
    pip install fastapi uvicorn pydantic
    ```

2. **Create the SQLite database** (run once):
    ```python
    import sqlite3
    conn = sqlite3.connect("complaints.db")
    cursor = conn.cursor()
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS complaints (
        complaint_id TEXT PRIMARY KEY,
        name TEXT,
        phone_number TEXT,
        email TEXT,
        complaint_details TEXT,
        created_at TEXT,
        complaint_status TEXT
    )
    """)
    conn.commit()
    conn.close()
    ```

3. **Run the API server**:
    ```sh
    uvicorn CR_api:app --reload
    ```

### 2. Frontend Setup (Streamlit + LangChain)

1. **Install dependencies**:
    ```sh
    pip install streamlit requests langchain langchain_groq
    ```

2. **Set your Groq API key**  
   (Already set in the code, but you should use your own key for production.)

3. **Run the chatbot UI**:
    ```sh
    streamlit run frontend_chat.py
    ```

4. **Open your browser** at [http://localhost:8501](http://localhost:8501) to interact with the chatbot.

## Usage

- **File a Complaint**: Start the conversation and follow the prompts to submit your complaint.
- **Retrieve a Complaint**: Ask about the status of a complaint and provide your complaint ID when prompted.

## Notes

- The backend must be running before starting the frontend.
- The SQLite database (`complaints.db`) will be created automatically if it does not exist.
- The chatbot uses Llama3 via Groq API for intent classification and response generation.

## License

MIT License

---

**Author:**  
Abhishek Ramawat
